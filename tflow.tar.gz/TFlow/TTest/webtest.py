#!/usr/bfin/python
#-*- coding: utf8 -*-

from webfetcher import WebFetcher
from webparser import Parser
from checker import Checker

from utility import get_attr

class WebTest(WebFetcher, Parser, Checker):
    def __init__(self):
        WebFetcher.__init__(self)
        Parser.__init__(self)
        Checker.__init__(self)
        

    def check(self, url, field_chain, op, value):
        repo = self.fetch(url)
        _format, obj = self.parse(repo.content)
        setattr(repo, 'body_type', _format)
        setattr(repo, 'body', obj)
        _value = get_attr(repo, field_chain)
        result = self.cmp(_value, op, value)
        return result
    
    def check_multi(self, url, testitems):
        repo = self.fetch(url)
        _format, obj = self.parse(repo.content)
        setattr(repo, 'body_type', _format)
        setattr(repo, 'body', obj)
        result = []
        for testitem in testitems:
            result.append(self._check_single(repo, testitem))
        return all(result)

    def _check_single(self, repo, testitem):
        field_chain = testitem['field_chain']
        op = testitem['operator']
        value = testitem['value']
        _value = get_attr(repo, field_chain)
        result = self.cmp(_value, op, value)
        return result
