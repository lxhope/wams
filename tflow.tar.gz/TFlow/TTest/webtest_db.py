#!/usr/bfin/python
#-*- coding: utf8 -*-

from webtest import WebTest
from models import db, Host, Interface, TestItem, TestResult

from utility import urlreplace

class WebTestByDB(WebTest):
    def __init__(self, host=None, interface=None):
        WebTest.__init__(self)
        self.host = host
        self.interface = interface
        if self. interface:
            self.url = self.interface.url

    def check(self, host=None, interface=None):
        if host:
            self.host = host
        if interface:
            self.interface = interface
            self.url = self.interface.url
        if self.host:
            if isinstance(self.host, Host):
                self.host = self.host.domain
            self.url = urlreplace(self.url, host=self.host)

        self.result = True
        for item in self.interface.testitems:
            self.result = WebTest.check(self, self.url, item.field_chain, item.operator, item.value)
            if not self.result:
                break

        return self.result
