#!/usr/bin/python
#-*- coding: utf8 -*-

import operator

OPERATORS = {
    '=' : 'eq',
    '!=': 'ne',
    '>' : 'gt',
    '>=': 'ge',
    '<' : 'lt',
    '<=': 'le',
}

class CheckerError(Exception):
    """ Raised when Checker fail. """

class Checker:
    def __init__(self):
        pass

    def cmp(self, left, op, right):
        funcname = OPERATORS.get(op, None)
        if not funcname:
            raise CheckerError(
                     'Not supported operator, operator must be one of the following: %s' % ';'.join(OPERATORS.keys()))
        cmp_func = getattr(operator, funcname)
        return cmp_func(left, right)
