#!/usr/bin/python
#-*- coding: utf8 -*-

import requests

class WebFetcherError(Exception):
    """ Error raised when WebFetcher fail. """

class WebFetcher:
    """ Web resource fetcher """
    def __init__(self):
        self.accept_methods = ['GET', 'POST', 'PUT', 'DELETE']

    def fetch(self, url, method='get', **kargs):
        if method.upper() not in self.accept_methods:
            raise WebFetcherError(
                     'HTTP method must be one of the following: %s' 
                      % ';'.join(self.accept_methods))
        func = getattr(requests, method.lower())
        return func(url, **kargs)
