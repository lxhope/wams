#!/usr/bfin/python
#-*- coding: utf8 -*-

import time
from Queue import Queue
import threading
from threading import Thread

from multiprocessing import Process

from utility import urlreplace

from webtest_db import WebTestByDB
from models import db, Host, Interface, TestItem, TestResult, make_session
from result_saver import ResultSaver


class TestWorker(WebTestByDB, Thread):
    """ Routines for test work thread. """
    def __init__(self, in_queue, out_queue, err_queue):
        WebTestByDB.__init__(self)
        Thread.__init__(self)
        
        self.in_queue = in_queue
        self.out_queue = out_queue
        self.err_queue = err_queue
        
        self.db_session = make_session()
        
        self.setDaemon(True)
        self.is_working = True
        self.start()

    def run(self):
        while True:
            # Process test tasks in the in_queue until command is stop.
            self.is_working = False
            command, testcase = self.in_queue.get()
            if command == 'stop':
                break
            try:
                if command != 'process':
                    raise ValueError('Unknown command %r' % command)
            except:
                self.report_error()
            else:
                self.is_working = True
                self.process(testcase)

    def process(self, testcase):
        host, interface_id = testcase
        interface = self.db_session.query(Interface).filter_by(id=interface_id).first()
        if interface:
            result = self.check(host, interface)
            url = urlreplace(interface.url, netloc=host)
            self.out_queue.put((interface.id, interface.name, url, result))
        
    def dismiss(self):
        self.db_session.close()
        command = 'stop'
        self.in_queue.put((command, None))

    def report_error(self):
        ''' We "report" errors by adding error information to err_queue. '''
        self.err_queue.put(sys.exc_info()[:2])

class TestProcess():
    """ Process testcase """
    max_workers = 16

    def __init__(self, pool_size=0):
        """ Spawn num_workers and initialize three queues. """
        # pool_size = 0 indicate buffer is unlimited.

        self.test_id = int(time.time())
        self.saver = ResultSaver(self.test_id)
        
        self.in_queue = Queue(pool_size)
        self.out_queue = Queue(pool_size)
        self.err_queue = Queue(pool_size)

        self.workers = {}
        self.testcases = []

    def make_workers(self, num_workers):
        num_workers = TestProcess.max_workers \
            if num_workers > TestProcess.max_workers \
            else num_workers
        for i in range(num_workers):
            worker = TestWorker(self.in_queue, self.out_queue, self.err_queue)
            self.workers[i] = worker

    def check(self, host, interface_ids=[]):
        self.make_workers(len(interface_ids))
        for _id in interface_ids:
            self.add_test(host, _id)
        self.save_results()
        self.destroy()

    def add_test(self, host, interface_id):
        command = 'process'
        self.in_queue.put((command, (host, interface_id)))
    
    def check_by_tag(self, host, tags):
        pass

    def save_results(self):
        while not self.is_finished() or not self.out_queue.empty():
            result = self.out_queue.get()
            self.saver.save(result)
            #time.sleep(0.1)
        self.saver.mark_finished()

    def is_finished(self):
        return not any([t.is_working for t in self.workers.values()])

    def destroy(self):
        # order is important: first, request all threads to stop...
        for i in self.workers:
            self.workers[i].dismiss()
        # ...then, wait for each of them to terminate;
        for i in self.workers:
            self.workers[i].join()
        # clean up the workers from now unused thread objects
        del self.workers


if __name__ == '__main__':
    tester = TestProcess()
    #tester.check(host='telematics-test.autonavi.com', interface_ids=[1, 2])
    print tester.test_id
    kwargs = {'host': 'telematics-test.autonavi.com', 'interface_ids': [1, 2, 3, 4, 5]*10}
    p = Process(target=tester.check, args=(kwargs['host'], kwargs['interface_ids']))
    #p.daemon = True
    print p.daemon
    p.start()
    p.join()
