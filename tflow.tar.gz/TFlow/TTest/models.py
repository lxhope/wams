#!/usr/bin/python
#-*-: coding: utf8 -*-

from flask import Flask
from flask.ext.sqlalchemy import SQLAlchemy, SessionBase

from datetime import datetime

app = Flask(__name__)
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db/ttest.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqldb://root:root@localhost:3306/telematics_test'
db = SQLAlchemy(app)

def make_session():
    session = SessionBase(bind=db.session.bind)
    return session

class Host(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name   =  db.Column(db.String(80), unique=True)
    domain = db.Column(db.String(80), unique=True)
    port   = db.Column(db.Integer)

    def __init__(self, name=None, domain=None, port=None):
        self.name = name
        self.domain = domain
        self.port = port

    def __repr__(self):
        return '<Host %s: %s:%s>' % (self.name, self.domain, self.port)

class InterfaceCategory(db.Model):
    """ """
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))

    def __init__(self, name=None):
        self.name = name

    def __repr__(self):
        return '<InterfaceCategory %s>' % self.name

testitems = db.Table('testitems',
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id')),
    db.Column('testitem_id', db.Integer, db.ForeignKey('testitem.id'))
)

interface_tags = db.Table('interface_tags',
    db.Column('interface_id', db.Integer, db.ForeignKey('interface.id')),
    db.Column('tag_id', db.Integer, db.ForeignKey('autotest_tag.id'))
)

class Interface(db.Model):
    """ Model which preserve url parse result by uroparse library. """
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80))
    category = db.Column(db.String(30))
    
    url = db.Column(db.String(2048))

    method = db.Column(db.String(16))
    timeout = db.Column(db.Integer, default=30)
    tags = db.relationship('Tag', secondary=interface_tags,
        backref=db.backref('interfaces', lazy='dynamic'))
    testitems = db.relationship('TestItem', secondary=testitems,
        backref=db.backref('interfaces', lazy='dynamic'))
    testresults = db.relationship('TestResult', backref='interface',
        lazy='dynamic')

    def __init__(self, name=None, url=None):
        self.name = name
        self.url = url

    def __repr__(self):
        return '<Interface %s>' % self.name

    def to_dict(self):
        data = {
            'id': self.id,
            'name': self.name,
            'url': self.url,
            'testitems': ';'.join([item.name for item in self.testitems]),
            'tags': ';'.join([tag.name for tag in self.tags])
        }
        return data

class TestItem(db.Model):
    __tablename__ = 'testitem'
    id = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String(80))
    field_chain   = db.Column(db.String(256))
    reg_exp = db.Column(db.String(256)) # Regular Expression
    operator   = db.Column(db.String(80))
    value  = db.Column(db.String(256))

    def __init__(self, name=None, field_chain=None, reg_exp=None, operator=None, value=None):
        self.name = name
        self.field_chain = field_chain
        self.reg_exp = reg_exp
        self.operator  = operator
        self.value = value

    def __repr__(self):
        return '<TestItem %s>' % self.name or self.id

class Tag(db.Model):
    __tablename__ = 'autotest_tag'
    id = db.Column(db.Integer, primary_key=True)
    name   = db.Column(db.String(80))
    description = db.Column(db.String(256))

    def __init__(self, name=None):
        self.name = name

    def __repr__(self):
        return '<Tag %s>' % self.name

class TestResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    interface_id = db.Column(db.Integer, db.ForeignKey('interface.id'))
    result = db.Column(db.Boolean())
    message = db.Column(db.String(256))
    testtime = db.Column(db.DateTime(), default=datetime.now())
    
    def __init__(self, result, message):
        self.result = result
        self.message = message

