#!/usr/bin/python
#-*- coding: utf8 -*-

from urllib import urlencode
from urlparse import urlparse, urlunparse, parse_qsl

_get_attr_raise_on_attribute_error = "RAISE ON EXCEPTION"

def get_attr(obj, string_rep, default=_get_attr_raise_on_attribute_error, separator="."):
    """ getattr via a chain of attributes like so:
    >>> import datetime
    >>> some_date = datetime.date.today()
    >>> get_attr(some_date, "month.numerator.__doc__")
    'int(x[, base]) -> integer\n\nConvert a string or number to an integer, ...
    """
    attribute_chain = string_rep.split(separator)

    current_obj = obj

    for attr in attribute_chain:
        try:
            if attr.isdigit() and isinstance(current_obj, (basestring, list, tuple)):
                current_obj = current_obj[int(attr)]
            else:
                current_obj = getattr(current_obj, attr)
        except IndexError:
            if default is _get_attr_raise_on_attribute_error:
                raise IndexError(
                    "Bad index \"{}\" in chain: \"{}\"".format(attr, string_rep)
                )
            return default
        except AttributeError:
            if default is _get_attr_raise_on_attribute_error:
                raise AttributeError(
                    "Bad attribute \"{}\" in chain: \"{}\"".format(attr, string_rep)
                )
            return default

    return current_obj

def urlreplace(
    url, 
    scheme = None, 
    netloc = None, 
    path = None,
    params = None, 
    query = None, 
    fragment = None, 
    *args, **kwargs
):
    """
    >>> url = "http://telematics.autonavi.com/ws/mapapi/poi/search/?channel=audi"
    >>> urlreplace(url, scheme='https')
    "https://telematics.autonavi.com/ws/mapapi/poi/search/?channel=audi"
    >>> urlreplace(url, path='/ws/mapapi/')
    'http://telematics.autonavi.com/ws/mapapi/?channel=audi'
    >>> urlreplace(url, netloc="10.2.134.29:8008")
    'http://10.2.134.29:8008/ws/mapapi/poi/search/?channel=audi'
    >>> urlreplace(url, params="where")
    'http://telematics.autonavi.com/ws/mapapi/poi/search/;where?channel=audi'
    >>> urlreplace(url, fragment="what")
    'http://telematics.autonavi.com/ws/mapapi/poi/search/?channel=audi#what'
    >>> urlreplace(url, querydict={'channel':'qoros', 'output':'json'})
    'http://telematics.autonavi.com/ws/mapapi/poi/search/?output=json&channel=qoros'
    >>> urlreplace(url, querydict={'channel':'qoros', 'output':'json'}, overwrite=False)
    'http://telematics.autonavi.com/ws/mapapi/poi/search/?output=json&channel=audi&channel=qoros'
    """
    prlist = list(urlparse(url))
    if scheme:
        prlist[0] = scheme
    if netloc:
        prlist[1] = netloc
    if path:
        prlist[2] = path
    if params:
        prlist[3] = params
    if query:
        prlist[4] = query
    if fragment:
        prlist[5] = fragment
    if 'querydict' in kwargs:
        _query = prlist[4]
        if isinstance(_query, unicode):
            _query = _query.encode('utf-8')
        _querydict = kwargs.get('querydict', {})
        _overwrite = kwargs.get('overwrite', True)
        if _overwrite:
            _querydict0 = dict(parse_qsl(_query))
            _querydict0.update(_querydict)
            prlist[4] = urlencode(_querydict0)
        else:
            _querydict0 = QueryDict(_query, encoding='utf-8').copy()
            _querydict0.update(_querydict)
            prlist[4] = urlencode(_querydict0.items())

    return urlunparse(prlist)

