#!/usr/bin/python
#-*- coding: utf8 -*-

import os
import logging
from t_service_test import TestProcess
import daemonic

root_dir = os.path.realpath(os.path.dirname(__file__))
pidfile = os.path.join(root_dir, "pid/daemonize.pid")
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
logger.propagate = False
log_file = os.path.join(root_dir, "log/daemonize-123.log")


def main():
    tester = TestProcess()
    print tester.test_id
    tester.check(host='telematics-test.autonavi.com', interface_ids=[1, 2])

if __name__ == '__main__':
    with daemonic.daemon(pidfile=pidfile):
        main()
