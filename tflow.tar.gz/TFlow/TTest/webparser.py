#!/usr/bin/python
#-*- coding: utf8 -*-

import json
import xmltodict

from easydict import EasyDict

SUPPORT_FORMATS = ['html', 'xml', 'json', 'jsonp']

class ParserError(Exception):
    """ Raised when Parser fail. """

class Parser:
    def __init__(self):
        pass

    def parse(self, raw_text, expect_format=None):
        real_format = None
        obj = None
        if expect_format and expect_format not in SUPPORT_FORMATS:
            raise ParserError(
                     'Not supported format, format must be one of the following: %s' % ';'.join(SUPPORT_FORMATS))
        elif expect_format=='xml':
            try:
                obj = xmltodict.parse(raw_text)
                real_format = expect_format
            except:
                raise ParserError('%s is not xml format' % raw_text)
        elif expect_format=='json':
            try:
                obj = json.loads(raw_text)
                real_format = expect_format
            except:
                raise ParserError('%s is not json format' % raw_text)
        else:
            try:
                obj = xmltodict.parse(raw_text)
                real_format = 'xml'
            except:
                pass
            if not real_format:
                try:
                    obj = json.loads(raw_text)
                    real_format = 'json'
                except:
                    pass
            if not real_format:
                # TODO parse html and jsonp and other formats.
                pass
             
        if not real_format:
            real_format = 'text'
            obj = raw_text
        else:
            obj = EasyDict(obj)
 
        return real_format, obj
