#!/usr/bin/python
#-*- coding: utf8 -*-

import os
import csv
import shutil

from pymongo import MongoClient
client = MongoClient('localhost', 27017)
db = client.telematics_test
test_result = db.test_result
test_process_mark = db.test_process_mark

class ResultSaver:
    def __init__(self, saver_id):
        root_dir = os.path.realpath(os.path.dirname(__file__))
        self.data_dir = os.path.join(root_dir, 'data')
        if not os.path.exists(self.data_dir):
            os.mkdir(self.data_dir)
        self.prefix = 'TestResult'
        self.saver_id = saver_id
        self.csv_file = '%s-%s.%s' % (self.prefix, self.saver_id, 'csv')
        self.csv_file_path = os.path.join(self.data_dir, self.csv_file)

    def save(self, result):
        self.save_to_csv(result)
        self.save_to_mongo(result)

    def save_to_csv(self, result):
        with open(self.csv_file_path, 'ab') as csvfile:
            w = csv.writer(csvfile)
            w.writerow(result)

    def save_to_mongo(self, result):
        r = {"interface_id": result[0],
             "test_id": self.saver_id,
             "name": result[1],
             "url": result[2],
             "result": result[3],
             "is_obtained": False}
        test_result.insert(r)

    def mark_finished(self):
        test_process_mark.insert({'test_id': self.saver_id, 'is_finished':True})

    def clean(self):
        test_result.remove()
        test_process_mark.remove()
        shutil.rmtree(self.data_dir)

if __name__ == '__main__':
    saver = ResultSaver(None)
    saver.clean()        
