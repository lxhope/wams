#/usr/bin/python
#-*- coding: utf8 -*-

import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from webtest_db import WebTestByDB
from models import db, Host, Interface, TestItem, TestResult

class WebTestByDBTestCase(unittest.TestCase):
    def setUp(self):
        db.create_all()
  
    def tearDown(self):
        #db.drop_all()
        pass

    def test_check(self):
        field_chain = 'body.ats.code'
        reg_exp = None
        op = '='
        value = '1'
        testitem = TestItem('Test', field_chain, reg_exp, op, value)
        host = Host('Test', 'telematics-test.autonavi.com', 80)
        interface = Interface('Test', 'http://telematics.autonavi.com/ws/mapapi/support-city?channel=autonavi&sign=B140EF1AAF9CE3542BCCAA9C8CC36737')
        interface.testitems.append(testitem)
        tester = WebTestByDB(host, interface)
        result = tester.check()
        self.assertTrue(result)
    
    def test_check_false(self):
        field_chain = 'body.ats.code'
        reg_exp = None
        op = '='
        value = '0'
        testitem = TestItem('Test', field_chain, reg_exp, op, value)
        host = Host('Test', 'telematics-test.autonavi.com', 80)
        interface = Interface('Test', 'http://telematics.autonavi.com/ws/mapapi/support-city?channel=autonavi&sign=B140EF1AAF9CE3542BCCAA9C8CC36737')
        interface.testitems.append(testitem)
        tester = WebTestByDB(host, interface)
        result = tester.check()
        self.assertFalse(result)

    def test_check_save_result(self):
        field_chain = 'body.ats.code'
        reg_exp = None
        op = '='
        value = '0'
        testitem = TestItem('Test', field_chain, reg_exp, op, value)
        host = Host('Test', 'telematics-test.autonavi.com', 80)
        interface = Interface('Test', 'http://telematics.autonavi.com/ws/mapapi/support-city?channel=autonavi&sign=B140EF1AAF9CE3542BCCAA9C8CC36737')
        interface.testitems.append(testitem)
        tester = WebTestByDB(host, interface, save_result=True)
        result = tester.check()
        self.assertFalse(result)
        
        result_count = TestResult.query.count()
        self.assertEqual(result_count, 1)

def test_main():
    test_support.run_unittest(WebTestByDBTestCase)

if __name__ == '__main__':
    test_main()

