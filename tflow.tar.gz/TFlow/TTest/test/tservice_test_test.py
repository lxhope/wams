#/usr/bin/python
#-*- coding: utf8 -*-

import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from t_service_test import TestProcess
from models import db, Host, Interface, TestItem, TestResult

class WebTestByDBTestCase(unittest.TestCase):
    def setUp(self):
        db.create_all()
        self.add_interface()
 
    def add_interface(self):
        field_chain = 'body.ats.code'
        reg_exp = None
        op = '='
        value = '1'
        testitem = TestItem('Test', field_chain, reg_exp, op, value)
        i1 = Interface('Adcode', 'http://telematics.autonavi.com/ws/mapapi/support-city?channel=autonavi&sign=B140EF1AAF9CE3542BCCAA9C8CC36737')
        i2 = Interface('AQI realtime', 'http://telematics.autonavi.com/ws/value_added/AQI/realtime/?&channel=autonavi&adcode=110117&longitude=116.405285&latitude=39.904989&sign=B13A2AAE307C9F53D0D315FCC18D0DD6&from=autonavi_test')
        i3 = Interface('Tip', 'http://telematics.autonavi.com/ws/mapapi/suggestion/tips/?city=010&words=KFC&channel=autonavi&sign=A1C0F0B598BC627419811AA74EACCA9C')
        i4 = Interface('POI Category', 'http://telematics.autonavi.com/ws/mapapi/poi/category?channel=autonavi&sign=B140EF1AAF9CE3542BCCAA9C8CC36737')
        i5 = Interface('Huafeng Weather', 'http://telematics.autonavi.com/ws/value_added/weather/hfinfo/?channel=autonavi&adcode=321200&sign=5E796E86DC3B03D8F851F11B9CD88E48&from=telematics_monitor')
        interfaces = [i1, i2, i3, i4, i5]
        for i in interfaces:
            i.testitems.append(testitem)
            db.session.add(i)
        db.session.commit()
         
    def tearDown(self):
        db.drop_all()
        pass

    def test_check_all(self):
        host = Host('Test', 'telematics-test.autonavi.com', 80)
        tester = TestProcess
        #tester.check_all_interface(host=host)
        interface_num = Interface.query.count()
        #result_num = TestResult.query.count()
        self.assertEqual(interface_num, 5)
        self.assertEqual(result_num, 5)

    def test_check_by_ids(self):
        host = Host('Test', 'telematics-test.autonavi.com', 80)
        #tester = TestProcess()
        #_ids = [2,3,4]
        #tester.check_interfaces(host=host, interface_ids=_ids)

def test_main():
    test_support.run_unittest(WebTestByDBTestCase)

if __name__ == '__main__':
    test_main()

