#/usr/bin/python
#-*- coding: utf8 -*-

import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from webfetcher import WebFetcher, WebFetcherError

class WebFetcherTestCase(unittest.TestCase):
    def setUp(self):
        self.fetcher = WebFetcher()
        self.test_url = 'http://www.baidu.com'
  
    def tearDown(self):
        pass

    def test_fetch_method(self):
        resp = self.fetcher.fetch(self.test_url, method='get')
        self.assertTrue(resp)

def test_main():
    test_support.run_unittest(WebFetcherTestCase)

if __name__ == '__main__':
    test_main()

