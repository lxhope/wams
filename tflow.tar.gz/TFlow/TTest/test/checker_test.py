#/usr/bin/python
#-*- coding: utf8 -*-

import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from checker import Checker, CheckerError

class CheckerTestCase(unittest.TestCase):
    def setUp(self):
        self.checker = Checker()
  
    def tearDown(self):
        pass

    def test_equal(self):
        result = self.checker.cmp('a', '=', 'a')
        self.assertTrue(result)

    def test_equal_false(self):
        result = self.checker.cmp('a', '=', 'b')
        self.assertFalse(result)

    def test_greater(self):
        result = self.checker.cmp(1, '>', 0)
        self.assertTrue(result)

    def test_greater_false(self):
        result = self.checker.cmp(1, '>', 1)
        self.assertFalse(result)

def test_main():
    test_support.run_unittest(CheckerTestCase)

if __name__ == '__main__':
    test_main()

