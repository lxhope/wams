#/usr/bin/python
#-*- coding: utf8 -*-

import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from webtest import WebTest

class WebTestTestCase(unittest.TestCase):
    def setUp(self):
        self.tester = WebTest()
        self.test_url = 'http://telematics.autonavi.com/ws/value_added/AQI/average/?longitude=116.405285&latitude=39.904989&channel=autonavi&sign=5AD0D718973EF68105499623884E0787'
  
    def tearDown(self):
        pass

    def test_check(self):
        field_chain = 'body.ats.code'
        op = '='
        value = '1'
        result = self.tester.check(self.test_url, field_chain, op, value)
        self.assertTrue(result)

def test_main():
    test_support.run_unittest(WebTestTestCase)

if __name__ == '__main__':
    test_main()

