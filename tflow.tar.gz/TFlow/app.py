#!/usr/bin/python
# -*- coding: utf8 -*-

from flask import Flask
from flask.ext.login import LoginManager, current_user
from flask.ext.sqlalchemy import SQLAlchemy

from flask.ext.admin import Admin
from flask_debugtoolbar import DebugToolbarExtension

from flask_mail import Mail

# Import the Permissions object
from flask.ext.permissions.core import Permissions

app = Flask(__name__)
app.config.from_pyfile('config.py')

@app.template_filter('datetime')
def format_datetime(value, format='medium'):
    return value.strftime('%Y-%m-%d %H:%M:%S')

db = SQLAlchemy(app)
mail = Mail(app)

admin = Admin(app)
#db.init_app(app)
#with app.test_request_context():
#    db.create_all()

# If you're using Flask-Login, this would be a good time to set that up.
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = '/login'
# Now, initialize a Permissions object. I've assigned it to a variable here,
# but you don't have to do so.
perms = Permissions(app, db, current_user)

#toolbar = DebugToolbarExtension(app)

