#!/usr/bin/python
#-*- coding: utf8 -*-

DEBUG = True
SECRET_KEY = '123abc'
#SQLALCHEMY_DATABASE_URI = 'sqlite:///db/tflow.db'
SQLALCHEMY_DATABASE_URI = 'mysql+mysqldb://root:root@localhost:3306/telematics_test'
# Configuration for email
MAIL_DEBUG = False
MAIL_SERVER = 'smtp.126.com'
MAIL_PORT = 25
MAIL_USE_TLS = False
MAIL_USE_SSL = False
MAIL_USERNAME = 'web_inform@126.com'
MAIL_DEFAULT_SENDER = 'web_inform@126.com'
MAIL_PASSWORD = 'uqnpdolnhakdcidn'

MONGO_DB_NAME = 'telematics_test'
MONGO_HOST = '127.0.0.1'
MONGO_PORT = 27017
MONGO_USERNAME = None
MONGO_PASSWORD = None
