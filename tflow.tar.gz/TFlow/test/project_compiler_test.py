import os
import random
import shutil
import unittest
from test import test_support

from os import sys, path
sys.path.append(path.dirname(path.dirname(path.abspath(__file__))))
from TBuild.project_compiler import ProjectCompiler, ProjectCompilerError

class ProjectCompilerCase(unittest.TestCase):

    # Only use setUp() and tearDown() if necessary

    def setUp(self):
        """ code to execute in preparation for tests """
        self.datapath = '/tmp/tflow'
        self.src_path = os.path.join(self.datapath, 'src')
        self.build_path = os.path.join(self.datapath, 'build')
        if not os.path.exists(self.datapath):
            os.mkdir(self.datapath)
        if not os.path.exists(self.src_path):
            os.mkdir(self.src_path)
        if not os.path.exists(self.build_path):
            os.mkdir(self.build_path)
	self.worker = ProjectCompiler()

    def tearDown(self):
        """ code to execute to clean up after tests """
        shutil.rmtree(self.datapath)

    def test_no_source_dir(self):
        """ testing code """
        tmp_dir = '/tmp/%s' % random.randint(100000000,99999999999)
        while os.path.exists(tmp_dir):
            tmp_dir = '/tmp/%s' % random.randint(100000000, 99999999999)
        self.assertRaises(ProjectCompilerError, self.worker.compile_and_copy, tmp_dir, tmp_dir)

    def test_no_build_dir(self):
        """ testing code """

    def test_copy_without_compile(self):
        filename = 'test.txt'
        filepath = os.path.join(self.src_path, filename)
        testpath = os.path.join(self.build_path, filename)
        with open(filepath, 'w') as f:
            f.write('test-copy')
        self.worker.compile_and_copy(self.src_path, self.build_path)
        result = os.path.exists(testpath)
        self.assertTrue(result)
    
    def test_copy_dir(self):
        path = 'test'
        os.mkdir(os.path.join(self.src_path, path))
        filepath = os.path.join(self.src_path, path)
        testpath = os.path.join(self.build_path, path)
        self.worker.compile_and_copy(self.src_path, self.build_path)
        result = os.path.exists(testpath) and os.path.isdir(testpath)
        self.assertTrue(result)

    def test_deep_copy_without_compile(self):
        rel_root = 'abc/def'
        os.makedirs(os.path.join(self.src_path, rel_root))
        filename = os.path.join(rel_root, 'test.txt')
        filepath = os.path.join(self.src_path, filename)
        testpath = os.path.join(self.build_path, filename)
        with open(filepath, 'w') as f:
            f.write('test-copy')
        self.worker.compile_and_copy(self.src_path, self.build_path)
        result = os.path.exists(testpath)
        self.assertTrue(result)

    def test_simple_compile(self):
        filename = 'test.py'
        pyc_file = '%s%s' % (filename, 'c')
        filepath = os.path.join(self.src_path, filename)
        test_py_path = os.path.join(self.build_path, filename)
        test_pyc_path = os.path.join(self.build_path, pyc_file)
        with open(filepath, 'w') as f:
            f.write('#test-copy')
        self.worker.compile_and_copy(self.src_path, self.build_path)
        result = os.path.exists(test_pyc_path)
        self.assertTrue(result)
        result = os.path.exists(test_py_path)
        self.assertFalse(result)

        
    def test_ignore(self):
        filename = 'test.py'
        pyc_file = '%s%s' % (filename, 'c')
        filepath = os.path.join(self.src_path, filename)
        test_py_path = os.path.join(self.build_path, filename)
        test_pyc_path = os.path.join(self.build_path, pyc_file)
        with open(filepath, 'w') as f:
            f.write('#test-copy')
        ignore_patterns = ['test']
        self.worker.compile_and_copy(self.src_path, self.build_path, ignore_patterns)
        result = os.path.exists(test_py_path)
        self.assertTrue(result)
        result = os.path.exists(test_pyc_path)
        self.assertFalse(result)
        
    def test_ignore_not_match(self):
        filename = 'test.py'
        pyc_file = '%s%s' % (filename, 'c')
        filepath = os.path.join(self.src_path, filename)
        test_py_path = os.path.join(self.build_path, filename)
        test_pyc_path = os.path.join(self.build_path, pyc_file)
        with open(filepath, 'w') as f:
            f.write('#test-copy')
        ignore_patterns = ['abcd']
        self.worker.compile_and_copy(self.src_path, self.build_path, ignore_patterns)
        result = os.path.exists(test_pyc_path)
        self.assertTrue(result)
        result = os.path.exists(test_py_path)
        self.assertFalse(result)
        
def test_main():
    test_support.run_unittest(ProjectCompilerCase)

if __name__ == '__main__':
    test_main()

