#!/usr/bin/python
#-*- coding: utf8 -*-

from flask import render_template

from app import app, db
from models import User
from utility import generate_random_password
from inform import Informer

def add_user(username, email,  role):
    password = generate_random_password()
    if app.config['DEBUG']:
        user = User(name=username, email=email, password=username, roles=[role])
    else:
        user = User(name=username, email=email, password=password, roles=[role])
    db.session.add(user)
    db.session.commit()
    html = render_template('email/user_added.html', user=user, appname='TSAM', password=password, url='http://demo.tsam.com/login')    
    informer = Informer()
    informer.send_mail(html, subject='TSAM Account Add', receiver=user.email)
