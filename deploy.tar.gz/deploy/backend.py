#!/usr/bin/python
#-*- coding: utf8 -*-

import os
import sys
import re

CUR_DIR = os.path.realpath(os.path.dirname(__file__))
PROJECT_DIR = os.path.join(CUR_DIR, '../TFlow')
cfg = 'config.py'

def make_db_uri(host='localhost', port='3306', dbname='test', username='root', password='root'):
    uri = 'mysql+mysqldb://{username}:{password}@{host}:{port}/{dbname}'
    return uri.format(host=host, port=port, username=username, password=password, dbname=dbname)

def set_config(key=None, value=None):
    context = None
    pattern = """[^#]%s\s*=\s*.*""" % key
    if isinstance(value, basestring) and value.isdigit():
        new_str = '\n%s = %s' % (key, value)
    else:
        new_str = '\n%s = "%s"' % (key, value)
    with open(cfg, 'r') as f:
        context = f.read()
    context = re.sub(pattern, new_str, context, flags=re.MULTILINE)
    with open(cfg, 'w') as f:
        f.write(context)

class Config:
    def __init__(self):
        pass

    @classmethod
    def chdir(cls):
        os.chdir(PROJECT_DIR)
 
    @classmethod
    def addpath(cls):
        sys.path.insert(0, PROJECT_DIR)

    @classmethod
    def set_mysql(cls, host, port, dbname, username, password):
        cls.chdir()
        key = 'SQLALCHEMY_DATABASE_URI'
        uri = make_db_uri(host, port, dbname, username, password)
        set_config(key, uri)
        return True

    @classmethod
    def set_mongo(cls, host, port, dbname, username, password):
        cls.chdir()
        set_config('MONGO_HOST', host)
        set_config('MONGO_PORT', port)
        set_config('MONGO_DB_NAME', dbname)
        set_config('MONGO_USERNAME', username)
        set_config('MONGO_PASSWORD', password)
        return True

    @classmethod
    def set_vcs(cls, _type, vcs_type, repo_url, username, password):
        cls.addpath()
        from TBuild.conf import Configuration
        cfg = Configuration('vcs')
        obj = dict(cfg.read().get(_type))
        obj['vcs_type'] = str(vcs_type)
        obj['repo_url'] = str(repo_url)
        obj['username'] = str(username)
        obj['password'] = str(password)
        cfg.update({_type: obj})
        return True

    @classmethod
    def set_superadmin(cls, name, email):
        cls.addpath()
        from app import app
        from misc import add_user
        with app.app_context():
            add_user(name, email, 'superadmin')
        return True
