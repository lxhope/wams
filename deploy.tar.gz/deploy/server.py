#!/usr/bin/python
#-*- coding:utf8 -*-

import os
from flask import Flask, request, render_template

from backend import Config

app = Flask(__name__)
app.debug = True
app.secret_key = 'abc123'

@app.route('/')
def wizard():
    return render_template('wizard.html')

@app.route('/config/mysql', methods=['POST'])
def set_mysql():
    host = request.form.get('host')
    port = request.form.get('port')
    dbname = request.form.get('dbname')
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        Config.set_mysql(host, port, dbname, username, password)
    except Exception, e:
        return str(e)
    return 'true'

@app.route('/config/mongo', methods=['POST'])
def set_mongo():
    host = request.form.get('host')
    port = request.form.get('port')
    dbname = request.form.get('dbname')
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        Config.set_mongo(host, port, dbname, username, password)
    except Exception, e:
        return str(e)
    return 'true'

@app.route('/config/vcs/source', methods=['POST'])
def set_cs_source():
    vcs_type = request.form.get('vcs_type')
    repo_url = request.form.get('repo_url')
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        Config.set_vcs('source', vcs_type, repo_url, username, password)
    except Exception, e:
        return str(e)
    return 'true'

@app.route('/config/vcs/build', methods=['POST'])
def set_vcs_build():
    vcs_type = request.form.get('vcs_type')
    repo_url = request.form.get('repo_url')
    username = request.form.get('username')
    password = request.form.get('password')
    try:
        Config.set_vcs('build', vcs_type, repo_url, username, password)
    except Exception, e:
        return str(e)
    return 'true'

@app.route('/config/superadmin', methods=['POST'])
def set_superadmin():
    name = request.form.get('name')
    email = request.form.get('email')
    try:
        Config.set_superadmin(name, email)
    except Exception, e:
        return str(e)
    return 'true'


if __name__ == '__main__':
    app.run(host='0.0.0.0')
